// Bağımsız sunucu:  npm start   (çevrimdışı prova: npm run prova)
import http from "node:http";
import os from "node:os";
import { CFG } from "./config.js";
import { loadAll } from "./store.js";
import { createEhliyetHandler } from "./api/handler.js";

loadAll();
const handler = createEhliyetHandler();
const server = http.createServer((req, res) => void handler(req, res));
server.listen(CFG.port, CFG.host, () => {
  const lan = Object.values(os.networkInterfaces())
    .flat()
    .find((i) => i && i.family === "IPv4" && !i.internal)?.address;
  console.log(`\n🚗 EHLİYET Denetçi hazır`);
  console.log(`   Ekran:        http://localhost:${CFG.port}${CFG.basePath}/`);
  if (lan) console.log(`   Ağdaki adres: http://${lan}:${CFG.port}${CFG.basePath}/   (yarışmacılar bu adresle bağlanır)`);
  console.log(`   API şeması:   http://localhost:${CFG.port}${CFG.basePath}/openapi.json`);
  console.log(`   Borsa:        ${CFG.upstream === "atk" ? "GERÇEK OKX demo (ATK " + CFG.atkArgs.join(" ") + ")" : CFG.upstream === "hybrid" ? "Hibrit: gerçek OKX fiyatları + sahte emir" : "Sahte (çevrimdışı)"}`);
  console.log(`   Hakem/kırmızı takım: ${CFG.anthropicKey ? `Claude (${CFG.examinerModel})` : "KAPALI: .env'e ANTHROPIC_API_KEY ekleyin (kural tabanlı hakem çalışır)"}`);
  console.log(`   API anahtarı: ${CFG.apiKey ? "gerekli" : "yok (herkes denetim başlatabilir)"}\n`);
});
